from flask import Flask, jsonify, request, render_template
import joblib, os, pandas as pd

app = Flask(__name__)

# Basic health check
@app.route("/")
def home():
    return "EV Fleet Management System - API is running"

@app.route("/api/vehicles", methods=["GET"])
def list_vehicles():
    path = os.path.join(os.path.dirname(__file__), "../datasets/vehicles.csv")
    df = pd.read_csv(path)
    return jsonify(df.to_dict(orient="records"))

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)