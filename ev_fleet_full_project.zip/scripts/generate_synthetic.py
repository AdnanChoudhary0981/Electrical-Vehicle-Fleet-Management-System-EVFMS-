# scripts/generate_synthetic.py
import pandas as pd
print("This repo includes synthetic datasets under /datasets")